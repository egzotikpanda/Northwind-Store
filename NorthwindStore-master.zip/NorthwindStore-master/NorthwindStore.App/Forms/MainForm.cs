﻿using NorthwindStore.App.DataAccess;
using NorthwindStore.App.ViewModels;
using System;
using System.Linq;
using System.Windows.Forms;

namespace NorthwindStore.App.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            lbxCategories.ContextMenuStrip = contextMenuStrip1;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            FillCategoriesListBox();
        }

        private void FillCategoriesListBox()
        {
            lbxCategories.Items.Clear();

            var db = new NORTHWNDEntities();

            var categories = db.Categories
                .OrderBy(x => x.CategoryName)
                .Select(x => //Projection (Yansıtma)
                new CategoryViewModel
                {
                    Id = x.CategoryID,
                    Name = x.CategoryName
                }).ToArray();

            lbxCategories.Items.AddRange(categories);
        }

        private void TestSomeLinqExtensionMethodsWithDbContext()
        {
            var db = new NORTHWNDEntities();

            #region example -1 insert
            //var employee = new Employee
            //{
            //    FirstName = "Bekir Cin",
            //    LastName = "Özdemir",
            //    BirthDate = new DateTime(1997, 10, 22),
            //    City = "İzmir",
            //    Country = "Turkey",
            //    Title = "Intern",
            //    TitleOfCourtesy = "Mr.",
            //    PostalCode = "35220",
            //    Address = "1450 sokak no: 12 Alsancak"
            //};

            //db.Employees.Add(employee); //insert

            ////you have to commit the changes to the database, otherwise there will be no changes

            //db.SaveChanges(); 
            #endregion

            //tüm personelleri sql'den çekiniz

            //System.Linq (Language integrated query)

            var employees = db.Employees.ToArray();

            //adında a harfi olan personeller

            var employeesWithLetterA = db.Employees
                .Where(x => x.FirstName.Contains("a")).ToList(); //ToList, ToArray vb. yapmazsanız sorgu SQL'de çalıştırılmaz (çoklu veri okurken)

            //şirket isimleri 10 karakterden uzun tedarikçi şirketler

            var suppliers = db.Suppliers.Where(x => x.CompanyName.Length > 10).ToList();

            //bugün doğum günü olan personeller?
            var employeesBornToday = db.Employees
                .Where(x => x.BirthDate.Value.Month == DateTime.Now.Month
                        && x.BirthDate.Value.Day == DateTime.Now.Day).ToList();

            //Eğer bugün doğum günü olan personelim varsa, form açılışında "bugün X adet personelin doğum günü var" mesajı yazdırın. (MessageBox ile)
            //hiç yoksa bir şey yapmayın (No MessageBox)

            if (employeesBornToday.Count > 0)
                MessageBox.Show($"You have {employeesBornToday.Count} employee(s) with birthday today!");

            //else halinde bugün doğum günü olan kimse yok

            //MessageBox.Show(employeesBornToday.Count > 0
            //    ? $"You have {employeesBornToday.Count} employee(s) with birthday today!"
            //    : "There is no one with birtday today");

            //toplam sipariş adedi 100'ü geçen personeller
            var employeesWithMoreThan100Orders = db.Employees
                .Where(x => x.Orders.Count > 100).ToList();

            //Geç gönderilen siparişler?

            var lateOrders = db.Orders.Where(x => x.RequiredDate < x.ShippedDate).ToList();

            //London'a gönderilen (kargolanan) kaç sipariş vardır?

            //var ordersCountToLondon = db.Orders.Where(x => x.ShipCity == "London").Count();
            var ordersCountToLondon = db.Orders.Count(x => x.ShipCity == "London");

            //Hiç siparişi olmayan personeller?

            //var employeesWithoutOrder = db.Employees.Where(x => x.Orders.Count == 0).ToList();
            var employeesWithoutOrders = db.Employees.Where(x => !x.Orders.Any()).ToList();

            //çoğul çağrılar (sorgular) 
            //ya tek bir entity elde etmek istiyorsam (en iyi olasılıkla)
            //tek Single (eğer tam olarak 1 kayıt bekliyorsak)
            //ilk First (ilk kayıtla ilgileniyorsak) //OrderBy, TOP 1
            //Find

            //biz ne zamanlar tam tamına tek bir entity bekleriz?
            //nesiyle arama yaparsak bir tane kayıt gelecektir? ID

            //Id'si 3 olan employee'yi getiriniz.
            var employeeWithId3 = db.Employees.Single(x => x.EmployeeID == 3);

            //2 gündür kullandığımız yöntemlerin adı: LINQ Extension Methods
            //Entity Framework ile bir ilgisi de yok, isterseniz array'lerin de içrisinde bunlarla arama yapabilirsiniz.,

            //what if, olmayan bir employeId ile tek bir kayıt çekmek istersek
            //var employeeWithId33 = db.Employees.Single(x => x.EmployeeID == 33);
            var employeeWithId33 = db.Employees.SingleOrDefault(x => x.EmployeeID == 33);

            //if (employeeWithId33 == null)
            //    MessageBox.Show("Böyle bir employee bulunmamaktadır");

            //var employeeWithLetterA = db.Employees.SingleOrDefault(x => x.FirstName.Contains("a"));

            var employeeWithLetterA = db.Employees.First(x => x.FirstName.Contains("a"));
            var employeeWithLetterE = db.Employees.FirstOrDefault(x => x.FirstName.Contains("e"));

            //Biz Id(Primary key) ile SingleOrDefault veya FirstOrDefault kullanacak kadar amatör müyüz?

            //Find(Key)

            var order = db.Orders.Find(10350);
            var orderDetail = db.Order_Details.Find(10248, 11); //OrderID, ProductID

            //Bazen bazı tablolarımızda composite key var, 2 sütun anahtar (Order_Details)

            //null check, defensive programming'in belkemiğidir.
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            InsertCategory();
            FillCategoriesListBox();
        }

        private void InsertCategory()
        {
            var db = new NORTHWNDEntities();

            if (db.Categories.Any(x => x.CategoryName == txtCategoryName.Text))
            {
                MessageBox.Show("Duplicate category name");
                return;
            }

            var category = new Category
            {
                CategoryName = txtCategoryName.Text,
                Description = txtCategoryDescription.Text
            };

            db.Categories.Add(category);
            db.SaveChanges();
        }

        private void lbxCategories_MouseDown(object sender, MouseEventArgs e)
        {
            lbxCategories.SelectedIndex = lbxCategories.IndexFromPoint(e.X, e.Y);
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (lbxCategories.SelectedIndex == -1)
                e.Cancel = true;
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {

            var dialogResult = MessageBox.Show("Are you sure you want to permanently delete the category?", "Delete", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.No)
                return;

            var selectedCategory = (CategoryViewModel)lbxCategories.SelectedItem;

            var db = new NORTHWNDEntities();

            //remove edeceğimiz category'yi okumamız lazım

            var categoryToDelete = db.Categories.Find(selectedCategory.Id);

            if (categoryToDelete == null)
                return; //if deleted after retrieving

            try
            {
                db.Categories.Remove(categoryToDelete);
                db.SaveChanges();
                FillCategoriesListBox();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //sizin form açılışında tüm kategoriler yüklendikten sonra, bu kategori silinmiş olabilir

            //Normalde DELETE ile veri silinmez
            //SoftDelete (Deleted sütununuzu update edersiniz)

            //Remove sadece development ortamında veya eğitim ortamında kullanılır

        }
    }
}
